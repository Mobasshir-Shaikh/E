
import hmac
import hashlib

key = b"secretkey"
message = b"Hello World"

mac = hmac.new(key, message, hashlib.sha256).hexdigest()

print("Original Message:", message.decode())
print("Generated MAC:", mac)

received_mac = hmac.new(
    key, message, hashlib.sha256
).hexdigest()

if hmac.compare_digest(mac, received_mac):
    print("Message is authentic and unchanged")
else:
    print("Message verification failed")
