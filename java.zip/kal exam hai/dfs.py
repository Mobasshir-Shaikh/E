graph = {0:[1,2,4], 1:[3,5], 2:[], 3:[6],
         4:[], 5:[], 6:[]}

def dls(node, goal, depth):
    print(node, end=" ")
    if node == goal:
        return True
    if depth > 0:
        for child in graph[node]:
            if dls(child, goal, depth-1):
                return True
    return False

for depth in range(4):
    print("\nDepth:", depth)
    if dls(0, 6, depth):
        print("\nGoal found!")
        break