p = 23
g = 5
a = 6
b = 15

A = pow(g, a, p)
B = pow(g, b, p)

alice_key = pow(B, a, p)
bob_key = pow(A, b, p)

print("Alice public value", A)
print("Bob's public value", B)
print("Alice's shared key", alice_key)
print("Bob's shared key", bob_key)