text = "HELLO"
key = 3

encrypted = ""

for ch in text:
    encrypted += chr((ord(ch) - 65 + key) % 26 + 65)

decrypted = ""

for ch in encrypted:
    decrypted += chr((ord(ch) - 65 - key) % 26 + 65)

print("Original Message", text)
print("Encrypted Message", encrypted)
print("Decrypted Message", decrypted)