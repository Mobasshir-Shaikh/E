p = 3
q = 11

n = p * q
phi = (p - 1) * (q - 1)

e = 3
d = 7

Message = 4

encrypted = pow(Message, e, n)
decrypted = pow(encrypted, d, n)

print("Public key", (e, n))
print("Private key", (d, n))
print("Original Message", Message)
print("Encrypted Message", encrypted)
print("Decrypted Message", decrypted)