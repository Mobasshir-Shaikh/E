text = "HELLOWORLD"
#encryption
rail1 = text[::2]
rail2 = text[1::2]
enc = rail1 + rail2

print("Encrypted", enc)

#decryption
mid = (len(enc) + 1) // 2

dec = ""

for i in range(len(text)):
    if i % 2 == 0:
        dec += enc[i // 2]
    else:
        dec += enc[mid + i // 2]

print("Decrypted", dec)